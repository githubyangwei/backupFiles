$(function() {
    var i = window.dialog({
        align: "top",
        content: '<div style="font-family:\'微软雅黑\'"><span style="font-size:18px;">感谢您的关注</span></br><span>如需洽谈合作、反馈问题，</span></br><span>欢迎联系我们：<a style="color:#b2cfed;" href="mailto:yuqing-help@baidu.com">yuqing-help@baidu.com</a></span><div>'
    }),
    n = window.dialog({
        align: "top",
        skin: "app-dialog",
        width: 320,
        height: 252,
        content: '<div><div class="top">扫码下载</div><div class="content"><div class="sec"><i class="android"></i><p>安卓</p></div><div class="sec right"><i class="ios"></i><p>ios</p></div></div></div>'
    }),
    t = {
        init: function() {
            this.bindEvent()
        },
        bindEvent: function() {
            $("#J_app").on({
                mouseenter: function() {
                    n.show($("#J_app")[0]),
                    $("#uc-safe-pwd-input").addClass("hide-uc-safe-pw")
                },
                mouseleave: function(i) {
                    n.node !== i.toElement && (n.close(), $("#uc-safe-pwd-input").removeClass("hide-uc-safe-pw"))
                }
            }),
            $(n.node).on("mouseleave",
            function() {
                $("#uc-safe-pwd-input").removeClass("hide-uc-safe-pw"),
                n.close()
            }),
            $("#contact").click(function() {
                i.width(300).show(document.getElementById("contact"))
            }),
            $(document).bind("click",
            function(n) {
                var t = $(n.target);
                0 === t.closest(".contact").length && 0 === t.closest(".ui-dialog").length && i.close()
            }),
            $(".mala-nav-list a").each(function() { (location.href + "/").indexOf($(this).attr("href")) > -1 && $(this).attr("href") ? $(this).addClass("active") : $(this).removeClass("active")
            })
        }
    };
    t.init()
});